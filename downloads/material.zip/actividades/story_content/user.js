function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6OMczqfptqo":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

